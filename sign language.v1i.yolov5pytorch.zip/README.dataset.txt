# sign language > 2025-03-09 1:39pm
https://universe.roboflow.com/uday-w1yjc/sign-language-3kxwl

Provided by a Roboflow user
License: CC BY 4.0

